import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  TextInput,
} from 'react-native';
import { supabase } from '@/lib/supabase';

type Product = {
  id: string;
  name: string;
  wholesale_price: number;
  retail_price: number;
  mrp: number;
  quantity: number;
  unit: 'grams' | 'count';
};

type BillItem = {
  product: Product;
  quantity: number;
};

export default function BillingScreen() {
  const [billType, setBillType] = useState<'retail' | 'wholesale'>('retail');
  const [products, setProducts] = useState<Product[]>([]);
  const [billItems, setBillItems] = useState<BillItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    loadProducts();
  }, []);

  async function loadProducts() {
    const { data, error } = await supabase
      .from('products')
      .select('*')
      .order('name');

    if (error) {
      console.error('Error loading products:', error);
      return;
    }

    setProducts(data);
  }

  const filteredProducts = products.filter((product) =>
    product.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const totalAmount = billItems.reduce((sum, item) => {
    const price = billType === 'retail' ? item.product.retail_price : item.product.wholesale_price;
    return sum + price * item.quantity;
  }, 0);

  async function createBill() {
    if (billItems.length === 0) return;

    const { data: bill, error: billError } = await supabase
      .from('bills')
      .insert({
        bill_type: billType,
        total_amount: totalAmount,
      })
      .select()
      .single();

    if (billError) {
      console.error('Error creating bill:', billError);
      return;
    }

    const billItemsData = billItems.map((item) => ({
      bill_id: bill.id,
      product_id: item.product.id,
      quantity: item.quantity,
      price: billType === 'retail' ? item.product.retail_price : item.product.wholesale_price,
    }));

    const { error: itemsError } = await supabase
      .from('bill_items')
      .insert(billItemsData);

    if (itemsError) {
      console.error('Error creating bill items:', itemsError);
      return;
    }

    // Update product quantities
    for (const item of billItems) {
      const { error: updateError } = await supabase
        .from('products')
        .update({ quantity: item.product.quantity - item.quantity })
        .eq('id', item.product.id);

      if (updateError) {
        console.error('Error updating product quantity:', updateError);
      }
    }

    // Reset bill
    setBillItems([]);
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>New Bill</Text>

      <View style={styles.billTypeContainer}>
        <TouchableOpacity
          style={[
            styles.billTypeButton,
            billType === 'retail' && styles.billTypeButtonActive,
          ]}
          onPress={() => setBillType('retail')}
        >
          <Text
            style={[
              styles.billTypeText,
              billType === 'retail' && styles.billTypeTextActive,
            ]}
          >
            Retail
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.billTypeButton,
            billType === 'wholesale' && styles.billTypeButtonActive,
          ]}
          onPress={() => setBillType('wholesale')}
        >
          <Text
            style={[
              styles.billTypeText,
              billType === 'wholesale' && styles.billTypeTextActive,
            ]}
          >
            Wholesale
          </Text>
        </TouchableOpacity>
      </View>

      <TextInput
        style={styles.searchInput}
        placeholder="Search products..."
        value={searchQuery}
        onChangeText={setSearchQuery}
      />

      <View style={styles.productList}>
        <FlatList
          data={filteredProducts}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={styles.productItem}
              onPress={() => {
                const existingItem = billItems.find(
                  (billItem) => billItem.product.id === item.id
                );
                if (existingItem) {
                  setBillItems(
                    billItems.map((billItem) =>
                      billItem.product.id === item.id
                        ? { ...billItem, quantity: billItem.quantity + 1 }
                        : billItem
                    )
                  );
                } else {
                  setBillItems([...billItems, { product: item, quantity: 1 }]);
                }
              }}
            >
              <Text style={styles.productName}>{item.name}</Text>
              <Text style={styles.productPrice}>
                ₹{billType === 'retail' ? item.retail_price : item.wholesale_price}
              </Text>
            </TouchableOpacity>
          )}
        />
      </View>

      <View style={styles.billSummary}>
        <Text style={styles.billTotal}>Total: ₹{totalAmount.toFixed(2)}</Text>
        <TouchableOpacity
          style={styles.createBillButton}
          onPress={createBill}
          disabled={billItems.length === 0}
        >
          <Text style={styles.createBillButtonText}>Create Bill</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
    paddingTop: 60,
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  billTypeContainer: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  billTypeButton: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
    backgroundColor: '#fff',
    marginHorizontal: 4,
    borderRadius: 8,
  },
  billTypeButtonActive: {
    backgroundColor: '#007AFF',
  },
  billTypeText: {
    fontSize: 16,
    color: '#666',
  },
  billTypeTextActive: {
    color: '#fff',
  },
  searchInput: {
    backgroundColor: '#fff',
    padding: 12,
    borderRadius: 8,
    marginBottom: 20,
  },
  productList: {
    flex: 1,
  },
  productItem: {
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 8,
    marginBottom: 8,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  productName: {
    fontSize: 16,
  },
  productPrice: {
    fontSize: 16,
    fontWeight: '600',
  },
  billSummary: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 12,
    marginTop: 20,
  },
  billTotal: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  createBillButton: {
    backgroundColor: '#007AFF',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  createBillButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '600',
  },
});