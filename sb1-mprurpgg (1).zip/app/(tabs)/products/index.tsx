import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, RefreshControl } from 'react-native';
import { Link } from 'expo-router';
import { Plus } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { format } from 'date-fns';

type Product = {
  id: string;
  name: string;
  wholesale_price: number;
  retail_price: number;
  mrp: number;
  quantity: number;
  unit: 'grams' | 'count';
  expiry_date: string;
};

export default function ProductsScreen() {
  const [products, setProducts] = useState<Product[]>([]);
  const [refreshing, setRefreshing] = useState(false);

  async function loadProducts() {
    const { data, error } = await supabase
      .from('products')
      .select('*')
      .order('name');

    if (error) {
      console.error('Error loading products:', error);
      return;
    }

    setProducts(data);
  }

  async function onRefresh() {
    setRefreshing(true);
    await loadProducts();
    setRefreshing(false);
  }

  useEffect(() => {
    loadProducts();
  }, []);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Products</Text>
        <Link href="/products/new" asChild>
          <TouchableOpacity style={styles.addButton}>
            <Plus size={24} color="#fff" />
          </TouchableOpacity>
        </Link>
      </View>

      <FlatList
        data={products}
        keyExtractor={(item) => item.id}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
        renderItem={({ item }) => (
          <Link href={`/products/${item.id}`} asChild>
            <TouchableOpacity style={styles.productCard}>
              <Text style={styles.productName}>{item.name}</Text>
              <View style={styles.productDetails}>
                <Text style={styles.price}>
                  MRP: ₹{item.mrp.toFixed(2)}
                </Text>
                <Text style={styles.quantity}>
                  Qty: {item.quantity} {item.unit}
                </Text>
                <Text style={styles.expiry}>
                  Expires: {format(new Date(item.expiry_date), 'dd/MM/yyyy')}
                </Text>
              </View>
            </TouchableOpacity>
          </Link>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
    paddingTop: 60,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
  },
  addButton: {
    backgroundColor: '#007AFF',
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
  },
  productCard: {
    backgroundColor: '#fff',
    marginHorizontal: 20,
    marginBottom: 12,
    padding: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  productName: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 8,
  },
  productDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  price: {
    color: '#666',
  },
  quantity: {
    color: '#666',
  },
  expiry: {
    color: '#666',
  },
});