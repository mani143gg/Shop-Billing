import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import { router } from 'expo-router';
import { supabase } from '@/lib/supabase';

export default function NewProductScreen() {
  const [name, setName] = useState('');
  const [wholesalePrice, setWholesalePrice] = useState('');
  const [retailPrice, setRetailPrice] = useState('');
  const [mrp, setMrp] = useState('');
  const [quantity, setQuantity] = useState('');
  const [unit, setUnit] = useState<'grams' | 'count'>('count');
  const [expiryDate, setExpiryDate] = useState('');

  async function handleSubmit() {
    const { error } = await supabase.from('products').insert({
      name,
      wholesale_price: parseFloat(wholesalePrice),
      retail_price: parseFloat(retailPrice),
      mrp: parseFloat(mrp),
      quantity: parseFloat(quantity),
      unit,
      expiry_date: expiryDate,
    });

    if (error) {
      console.error('Error creating product:', error);
      return;
    }

    router.back();
  }

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>New Product</Text>

      <View style={styles.form}>
        <View style={styles.inputGroup}>
          <Text style={styles.label}>Name</Text>
          <TextInput
            style={styles.input}
            value={name}
            onChangeText={setName}
            placeholder="Product name"
          />
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Wholesale Price</Text>
          <TextInput
            style={styles.input}
            value={wholesalePrice}
            onChangeText={setWholesalePrice}
            placeholder="0.00"
            keyboardType="decimal-pad"
          />
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Retail Price</Text>
          <TextInput
            style={styles.input}
            value={retailPrice}
            onChangeText={setRetailPrice}
            placeholder="0.00"
            keyboardType="decimal-pad"
          />
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>MRP</Text>
          <TextInput
            style={styles.input}
            value={mrp}
            onChangeText={setMrp}
            placeholder="0.00"
            keyboardType="decimal-pad"
          />
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Quantity</Text>
          <TextInput
            style={styles.input}
            value={quantity}
            onChangeText={setQuantity}
            placeholder="0"
            keyboardType="decimal-pad"
          />
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Unit</Text>
          <View style={styles.unitSelector}>
            <TouchableOpacity
              style={[
                styles.unitButton,
                unit === 'count' && styles.unitButtonActive,
              ]}
              onPress={() => setUnit('count')}
            >
              <Text
                style={[
                  styles.unitButtonText,
                  unit === 'count' && styles.unitButtonTextActive,
                ]}
              >
                Count
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.unitButton,
                unit === 'grams' && styles.unitButtonActive,
              ]}
              onPress={() => setUnit('grams')}
            >
              <Text
                style={[
                  styles.unitButtonText,
                  unit === 'grams' && styles.unitButtonTextActive,
                ]}
              >
                Grams
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Expiry Date</Text>
          <TextInput
            style={styles.input}
            value={expiryDate}
            onChangeText={setExpiryDate}
            placeholder="YYYY-MM-DD"
          />
        </View>

        <TouchableOpacity style={styles.submitButton} onPress={handleSubmit}>
          <Text style={styles.submitButtonText}>Create Product</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
    paddingTop: 60,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 20,
    paddingHorizontal: 20,
  },
  form: {
    padding: 20,
  },
  inputGroup: {
    marginBottom: 20,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 8,
    color: '#666',
  },
  input: {
    backgroundColor: '#fff',
    padding: 12,
    borderRadius: 8,
    fontSize: 16,
  },
  unitSelector: {
    flexDirection: 'row',
  },
  unitButton: {
    flex: 1,
    padding: 12,
    backgroundColor: '#fff',
    alignItems: 'center',
    marginHorizontal: 4,
    borderRadius: 8,
  },
  unitButtonActive: {
    backgroundColor: '#007AFF',
  },
  unitButtonText: {
    fontSize: 16,
    color: '#666',
  },
  unitButtonTextActive: {
    color: '#fff',
  },
  submitButton: {
    backgroundColor: '#007AFF',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 20,
  },
  submitButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '600',
  },
});