/*
  # Initial Schema Setup for Shop Billing System

  1. New Tables
    - `products`
      - `id` (uuid, primary key)
      - `name` (text)
      - `wholesale_price` (numeric)
      - `retail_price` (numeric)
      - `mrp` (numeric)
      - `quantity` (numeric)
      - `unit` (text) - 'grams' or 'count'
      - `expiry_date` (date)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `bills`
      - `id` (uuid, primary key)
      - `bill_type` (text) - 'wholesale' or 'retail'
      - `total_amount` (numeric)
      - `created_at` (timestamp)
    
    - `bill_items`
      - `id` (uuid, primary key)
      - `bill_id` (uuid, foreign key)
      - `product_id` (uuid, foreign key)
      - `quantity` (numeric)
      - `price` (numeric)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create products table
CREATE TABLE products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  wholesale_price numeric NOT NULL,
  retail_price numeric NOT NULL,
  mrp numeric NOT NULL,
  quantity numeric NOT NULL,
  unit text NOT NULL CHECK (unit IN ('grams', 'count')),
  expiry_date date NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create bills table
CREATE TABLE bills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_type text NOT NULL CHECK (bill_type IN ('wholesale', 'retail')),
  total_amount numeric NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create bill_items table
CREATE TABLE bill_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bill_id uuid REFERENCES bills(id) ON DELETE CASCADE,
  product_id uuid REFERENCES products(id) ON DELETE RESTRICT,
  quantity numeric NOT NULL,
  price numeric NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE bills ENABLE ROW LEVEL SECURITY;
ALTER TABLE bill_items ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Enable all access for authenticated users" ON products
  FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Enable all access for authenticated users" ON bills
  FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Enable all access for authenticated users" ON bill_items
  FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger for products table
CREATE TRIGGER update_products_updated_at
  BEFORE UPDATE ON products
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();